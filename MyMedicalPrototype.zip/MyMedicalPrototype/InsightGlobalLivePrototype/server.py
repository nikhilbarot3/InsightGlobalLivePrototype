# import io
# import uuid
# from typing import Optional
# from fastapi import FastAPI, File, Form, UploadFile, HTTPException
# from fastapi.responses import HTMLResponse
# from pypdf import PdfReader
# from pydantic import BaseModel
# from langgraph.types import Command

# # Import compiled LangGraph app from agent.py
# from agent import app

# server = FastAPI(title="MyMedical Pre-Authorization Portal")


# class DecisionPayload(BaseModel):
#     thread_id: str
#     decision: str  # "APPROVED" or "REJECTED"
#     notes: Optional[str] = "Reviewed via Provider Portal"


# @server.get("/", response_class=HTMLResponse)
# async def serve_ui():
#     """Serves the minimal single-page HTML UI."""
#     with open("index.html", "r", encoding="utf-8") as f:
#         return f.read()


# @server.post("/api/process")
# async def process_claim(
#     input_type: str = Form(...),  # 'text', 'txt_file', or 'pdf_file'
#     raw_text: Optional[str] = Form(None),
#     file: Optional[UploadFile] = File(None)
# ):
#     extracted_text = ""

#     if input_type == "text":
#         if not raw_text or not raw_text.strip():
#             raise HTTPException(status_code=400, detail="Text field cannot be empty.")
#         extracted_text = raw_text.strip()

#     elif input_type == "txt_file":
#         if not file:
#             raise HTTPException(status_code=400, detail="Please upload a .txt file.")
#         content = await file.read()
#         extracted_text = content.decode("utf-8", errors="ignore").strip()

#     elif input_type == "pdf_file":
#         if not file:
#             raise HTTPException(status_code=400, detail="Please upload a PDF file.")
#         content = await file.read()
#         try:
#             reader = PdfReader(io.BytesIO(content))
#             extracted_text = "\n".join(
#                 [page.extract_text() for page in reader.pages if page.extract_text()]
#             ).strip()
#         except Exception as e:
#             raise HTTPException(status_code=400, detail=f"PDF parsing error: {str(e)}")

#     if not extracted_text:
#         raise HTTPException(status_code=400, detail="Could not extract readable text from input.")

#     # Unique thread for this submission
#     thread_id = f"claim-{uuid.uuid4().hex[:8]}"
#     config = {"configurable": {"thread_id": thread_id}}

#     # Stream the graph execution
#     events = []
#     for event in app.stream({"raw_bill_text": extracted_text}, config):
#         events.append(event)

#     # Check whether the graph paused at an interrupt (HITL) or finished
#     state = app.get_state(config)

#     if state.tasks and state.tasks[0].interrupts:
#         interrupt_val = state.tasks[0].interrupts[0].value
#         return {
#             "thread_id": thread_id,
#             "status": "REQUIRES_HITL",
#             "extracted_text": extracted_text,
#             "details": interrupt_val
#         }

#     return {
#         "thread_id": thread_id,
#         "status": state.values.get("final_status", "UNKNOWN"),
#         "extracted_text": extracted_text,
#         "details": {
#             "total_amount": state.values.get("total_amount"),
#             "bill_data": state.values.get("bill_data"),
#             "reviewer_notes": state.values.get("reviewer_notes"),
#             "hipaa_compliant": state.values.get("hipaa_compliant"),
#             "policy_verified": state.values.get("policy_verified")
#         }
#     }


# @server.post("/api/resume")
# async def resume_claim(payload: DecisionPayload):
#     """Resumes graph execution when human reviewer submits an action."""
#     config = {"configurable": {"thread_id": payload.thread_id}}
#     state = app.get_state(config)

#     if not state.tasks or not state.tasks[0].interrupts:
#         raise HTTPException(status_code=400, detail="No pending human review for this claim.")

#     resume_command = Command(resume={"decision": payload.decision, "notes": payload.notes})
    
#     for _ in app.stream(resume_command, config):
#         pass

#     updated_state = app.get_state(config)
#     return {
#         "thread_id": payload.thread_id,
#         "status": updated_state.values.get("final_status"),
#         "details": {
#             "reviewer_notes": updated_state.values.get("reviewer_notes"),
#             "total_amount": updated_state.values.get("total_amount")
#         }
#     }


# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run("server:server", host="127.0.0.1", port=8000, reload=True)

import io
import uuid
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from pypdf import PdfReader
from pydantic import BaseModel
from langgraph.types import Command

from agent import app



server = FastAPI(title="MyMedical Pre-Authorization Portal (Observed)")


class DecisionPayload(BaseModel):
    thread_id: str
    decision: str
    notes: Optional[str] = "Reviewed via Provider Portal"


@server.get("/", response_class=HTMLResponse)
async def serve_ui():
    with open("index.html", "r", encoding="utf-8") as f:
        return f.read()


@server.post("/api/process")
async def process_claim(
    input_type: str = Form(...),
    raw_text: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None)
):
    extracted_text = ""

    if input_type == "text":
        if not raw_text or not raw_text.strip():
            raise HTTPException(status_code=400, detail="Text field cannot be empty.")
        extracted_text = raw_text.strip()

    elif input_type == "txt_file":
        if not file:
            raise HTTPException(status_code=400, detail="Please upload a .txt file.")
        content = await file.read()
        extracted_text = content.decode("utf-8", errors="ignore").strip()

    elif input_type == "pdf_file":
        if not file:
            raise HTTPException(status_code=400, detail="Please upload a PDF file.")
        content = await file.read()
        try:
            reader = PdfReader(io.BytesIO(content))
            extracted_text = "\n".join(
                [page.extract_text() for page in reader.pages if page.extract_text()]
            ).strip()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"PDF parsing error: {str(e)}")

    if not extracted_text:
        raise HTTPException(status_code=400, detail="Could not extract readable text from input.")

    # Unique identifiers for State Checkpointing and LangSmith Tracing
    claim_id = uuid.uuid4().hex[:8]
    thread_id = f"claim-{claim_id}"
    trace_id = str(uuid.uuid4())

    # RunnableConfig injected with LangSmith metadata & run_id
    config = {
        "configurable": {"thread_id": thread_id},
        "run_id": trace_id,
        "run_name": f"preauth-evaluation-{thread_id}",
        "metadata": {
            "environment": "debug",
            "thread_id": thread_id,
            "input_type": input_type
        },
        "tags": ["healthcare", "preauth", "prototype"]
    }

    # Stream graph execution
    events = []
    for event in app.stream({"raw_bill_text": extracted_text}, config):
        events.append(event)

    state = app.get_state(config)

    if state.tasks and state.tasks[0].interrupts:
        interrupt_val = state.tasks[0].interrupts[0].value
        return {
            "thread_id": thread_id,
            "trace_id": trace_id,
            "status": "REQUIRES_HITL",
            "extracted_text": extracted_text,
            "details": interrupt_val
        }

    return {
        "thread_id": thread_id,
        "trace_id": trace_id,
        "status": state.values.get("final_status", "UNKNOWN"),
        "extracted_text": extracted_text,
        "details": {
            "total_amount": state.values.get("total_amount"),
            "bill_data": state.values.get("bill_data"),
            "reviewer_notes": state.values.get("reviewer_notes"),
            "hipaa_compliant": state.values.get("hipaa_compliant"),
            "policy_verified": state.values.get("policy_verified")
        }
    }


@server.post("/api/resume")
async def resume_claim(payload: DecisionPayload):
    config = {
        "configurable": {"thread_id": payload.thread_id},
        "run_name": f"hitl-resumption-{payload.thread_id}",
        "metadata": {
            "action": "human_in_the_loop_resolution",
            "decision": payload.decision
        },
        "tags": ["hitl", "resume"]
    }
    
    state = app.get_state(config)
    if not state.tasks or not state.tasks[0].interrupts:
        raise HTTPException(status_code=400, detail="No pending human review for this claim.")

    resume_command = Command(resume={"decision": payload.decision, "notes": payload.notes})
    
    for _ in app.stream(resume_command, config):
        pass

    updated_state = app.get_state(config)
    return {
        "thread_id": payload.thread_id,
        "status": updated_state.values.get("final_status"),
        "details": {
            "reviewer_notes": updated_state.values.get("reviewer_notes"),
            "total_amount": updated_state.values.get("total_amount")
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:server", host="127.0.0.1", port=8000, reload=True)