import os
import re
import warnings

from typing import Dict, Any, Optional
from typing_extensions import TypedDict
from pydantic import BaseModel, Field

from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
# Alternative: for open-source LLaMA via Ollama / vLLM:
# from langchain_community.chat_models import ChatOllama

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command
from dotenv import load_dotenv
import logging
from langchain_core.globals import set_debug, set_verbose

# 1. Enable LangChain verbose & detailed debug mode
set_debug(True)
set_verbose(True)

# 2. Configure Python root logger to emit INFO/DEBUG to terminal
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)

# Load LangSmith and Gemini credentials from .env
load_dotenv()

# Suppress LangChain / Google GenAI configuration notices
warnings.filterwarnings("ignore", category=UserWarning, module="langchain_google_genai")

from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command

# ==========================================
# 1. State Definition & Structured Schemas
# ==========================================

class BillBreakupSchema(BaseModel):
    treatments: list[str] = Field(description="Extracted list of treatments/procedures")
    total_amount: float = Field(description="Total dollar amount parsed from the bill")
    patient_id: Optional[str] = Field(default=None, description="Patient identifier if found")

class PolicyVerificationSchema(BaseModel):
    policy_identified: bool = Field(description="True if an applicable policy is matched")
    policy_name: Optional[str] = Field(default=None, description="Name or code of the policy")
    policy_compliant: bool = Field(description="True if the procedure is covered under the policy")
    reasoning: str = Field(description="Explanation of coverage status")


class AgentState(TypedDict):
    raw_bill_text: str
    sanitized_text: str
    bill_data: Optional[Dict[str, Any]]
    total_amount: float
    policy_verified: bool
    policy_identified: bool
    hipaa_compliant: bool
    final_status: str
    reviewer_notes: Optional[str]


# ==========================================
# 2. LLM Initialization
# ==========================================

# Using Gemini (Set GEMINI_API_KEY or GOOGLE_API_KEY in environment)
# For open-source, swap with: llm = ChatOllama(model="llama3", temperature=0)
llm = ChatGoogleGenerativeAI(model="gemini-3.5-flash-lite", temperature=0)


# ==========================================
# 3. Agent Nodes
# ==========================================

def pii_masking_node(state: AgentState) -> Dict[str, Any]:
    """Masks obvious PII (SSN, Phone, Email) before LLM inference."""
    raw_text = state["raw_bill_text"]
    
    # Deterministic scrubbing for critical identifiers
    sanitized = re.sub(r"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED_SSN]", raw_text)
    sanitized = re.sub(r"\b\d{3}[-.\s]??\d{3}[-.\s]??\d{4}\b", "[REDACTED_PHONE]", sanitized)
    sanitized = re.sub(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", "[REDACTED_EMAIL]", sanitized)
    
    return {"sanitized_text": sanitized}


def bill_breakdown_agent(state: AgentState) -> Dict[str, Any]:
    """Agent 1: Extracts treatments, line items, and total amount."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", "Extract the breakdown of treatments and total amount from the sanitized bill. Return structured data."),
        ("user", "{text}")
    ])
    structured_llm = llm.with_structured_output(BillBreakupSchema)
    chain = prompt | structured_llm
    
    result: BillBreakupSchema = chain.invoke({"text": state["sanitized_text"]})
    return {
        "bill_data": result.model_dump(),
        "total_amount": result.total_amount
    }


def policy_verification_agent(state: AgentState) -> Dict[str, Any]:
    """Agent 2: Verifies treatments against available insurance policy rules."""
    # Mock insurance policy knowledge base
    mock_policy_rules = (
        "- Basic Consultation / Checkup: Covered under Plan Standard\n"
        "- Flu Shot / Routine Vaccines: Covered under Plan Preventive\n"
        "- General Blood Test / CBC: Covered under Plan Diagnostic\n"
        "- Cosmetic Surgery / Elective Dental: Not covered\n"
    )
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", f"Verify if the treatments match coverage rules:\n{mock_policy_rules}"),
        ("user", "Bill Treatments: {treatments}\nTotal Amount: ${total_amount}")
    ])
    
    structured_llm = llm.with_structured_output(PolicyVerificationSchema)
    chain = prompt | structured_llm
    
    bill_data = state.get("bill_data") or {}
    result: PolicyVerificationSchema = chain.invoke({
        "treatments": bill_data.get("treatments", []),
        "total_amount": state.get("total_amount", 0.0)
    })
    
    return {
        "policy_identified": result.policy_identified,
        "policy_verified": result.policy_compliant
    }


def hipaa_compliance_agent(state: AgentState) -> Dict[str, Any]:
    """Agent 3: Validates text for any remaining HIPAA compliance breaches."""
    sanitized = state["sanitized_text"]
    # Check if raw sensitive patterns escaped the masking step
    has_leak = bool(re.search(r"\b\d{3}-\d{2}-\d{4}\b", sanitized))
    return {"hipaa_compliant": not has_leak}


def human_review_node(state: AgentState) -> Dict[str, Any]:
    """HITL Node: Pauses execution if amount > $50 or policy is unrecognized."""
    review_payload = {
        "reason": "Exceeds $50 auto-approval threshold" if state["total_amount"] > 50 else "Policy unidentified/unverified",
        "total_amount": state["total_amount"],
        "treatments": state["bill_data"].get("treatments") if state.get("bill_data") else [],
        "hipaa_compliant": state["hipaa_compliant"]
    }
    
    # LangGraph interrupt halts execution and waits for human input via Command(resume=...)
    human_response = interrupt(review_payload)
    
    decision = human_response.get("decision", "REJECTED")
    notes = human_response.get("notes", "Reviewed by human operator")
    
    return {
        "final_status": decision,
        "reviewer_notes": notes
    }


def auto_approval_node(state: AgentState) -> Dict[str, Any]:
    """Approves claims <= $50 automatically."""
    return {
        "final_status": "APPROVED",
        "reviewer_notes": "Auto-approved by policy agent (<= $50.00)"
    }


# ==========================================
# 4. Routing Logic
# ==========================================

def route_approval(state: AgentState) -> str:
    """Gatekeeper logic checking HIPAA, Policy, and the $50 threshold."""
    if not state.get("hipaa_compliant"):
        return "human_review_node"
    
    if not state.get("policy_identified") or not state.get("policy_verified"):
        return "human_review_node"
    
    if state.get("total_amount", 0) <= 50.0:
        return "auto_approval_node"
    
    return "human_review_node"


# ==========================================
# 5. Build and Compile the Graph
# ==========================================

workflow = StateGraph(AgentState)

# Add Nodes
workflow.add_node("pii_masking_node", pii_masking_node)
workflow.add_node("bill_breakdown_agent", bill_breakdown_agent)
workflow.add_node("policy_verification_agent", policy_verification_agent)
workflow.add_node("hipaa_compliance_agent", hipaa_compliance_agent)
workflow.add_node("auto_approval_node", auto_approval_node)
workflow.add_node("human_review_node", human_review_node)

# Add Edges
workflow.add_edge(START, "pii_masking_node")
workflow.add_edge("pii_masking_node", "bill_breakdown_agent")
workflow.add_edge("bill_breakdown_agent", "policy_verification_agent")
workflow.add_edge("policy_verification_agent", "hipaa_compliance_agent")

workflow.add_conditional_edges(
    "hipaa_compliance_agent",
    route_approval,
    {
        "auto_approval_node": "auto_approval_node",
        "human_review_node": "human_review_node"
    }
)

workflow.add_edge("auto_approval_node", END)
workflow.add_edge("human_review_node", END)

# In-memory checkpointer is mandatory for interrupt / HITL support
memory = MemorySaver()
app = workflow.compile(checkpointer=memory)


# ==========================================
# 6. Execution Examples
# ==========================================

# if __name__ == "__main__":
#     # --- Case 1: Under $50 (Auto-Approval) ---
#     print("--- Running Case 1: Under $50 ---")
#     thread_1 = {"configurable": {"thread_id": "session-claim-001"}}
#     bill_input_1 = "Patient SSN: 000-12-3456 received a Routine Flu Shot. Total cost: $40.00"
    
#     for event in app.stream({"raw_bill_text": bill_input_1}, thread_1):
#         print(event)
    
#     # # --- Case 2: Over $50 (Requires HITL) ---
#     print("\n--- Running Case 2: Over $50 (Triggers HITL) ---")
#     thread_2 = {"configurable": {"thread_id": "session-claim-002"}}
#     bill_input_2 = "Patient received Basic Consultation and Diagnostic CBC panel. Total cost: $120.00"
    
#     # Graph execution will pause at human_review_node
#     for event in app.stream({"raw_bill_text": bill_input_2}, thread_2):
#         print(event)
    
#     # Inspect paused state
#     state_details = app.get_state(thread_2)
#     print("\n[PAUSED STATE INTERRUPT DETAILS]:", state_details.tasks[0].interrupts)
    
#     # Simulate Human Resuming with Approval
#     print("\n--- Resuming HITL with Human Decision ---")
#     resume_payload = Command(resume={"decision": "APPROVED", "notes": "Authorized by Senior Reviewer"})
    
#     for event in app.stream(resume_payload, thread_2):
#         print(event)